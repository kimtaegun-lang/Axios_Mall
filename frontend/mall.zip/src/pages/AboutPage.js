const AboutPage=()=> {
    return (
        <div className="text-3xl">AboutPage</div>
    );
}
export default AboutPage;